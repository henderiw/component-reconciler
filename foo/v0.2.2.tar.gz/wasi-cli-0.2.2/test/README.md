# Testing guidelines

TK fill in testing guidelines

## Installing the tools

TK fill in instructions

## Running the tests

TK fill in instructions
